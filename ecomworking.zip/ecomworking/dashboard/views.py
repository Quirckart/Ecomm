from .models import Category, Subcategory, Item
from .serializers import CategorySerializer, SubCategorySerializer, ItemSerializer
from rest_framework.permissions import IsAdminUser
from rest_framework import viewsets
from rest_framework.decorators import action
from .models import Affiliate, AffiliateLink, Item, Order
from .serializers import AffiliateLinkSerializer, OrderSerializer,AffiliateLoginSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import AffiliateLink
from .serializers import ItemSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate, login
from django.middleware.csrf import get_token
from rest_framework.permissions import AllowAny
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from rest_framework import viewsets,mixins
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser
from rest_framework import status
from django.db.models import Q
from fuzzywuzzy import process
from rest_framework.decorators import api_view

from .models import Category
from .serializers import CategorySerializer
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from rest_framework import status
from .models import Item, Keyword,Affiliate
from .serializers import ItemSerializer,ItemSearch
from rest_framework.generics import CreateAPIView
from .serializers import KeywordSerializer,CategorySerializerto
from rest_framework.pagination import PageNumberPagination

class ItemPagination(PageNumberPagination):
    page_size = 30  # Number of items per page
class StandardResultsSetPagination(PageNumberPagination):
    page_size = 10  # You can adjust this value


class AuthenticatedCheckView(APIView):
    # Disable authentication and permission checks for this view
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)  # Log the user in to create a session
            csrf_token = get_token(request)  # Get CSRF token
            sessionid = request.session.session_key  # Get session ID
            return Response({
                "status": "success",
                "statuscode":status.HTTP_200_OK,
                "csrf": csrf_token,
                "sessionid": sessionid
            }, status=status.HTTP_200_OK)
        else:
            return Response({"status": "fail"}, status=status.HTTP_401_UNAUTHORIZED)
class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]


    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            return Response({"status": "success", "data": serializer.data, "statuscode": status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        try:
            item = self.get_object()
            self.perform_destroy(item)
            return Response({"status": "success", "message": "Category deleted successfully.", "statuscode":status.HTTP_204_NO_CONTENT}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({"status": "fail", "message": str(e), "statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)
class SubCategoryViewSet(viewsets.ModelViewSet):
    queryset = Subcategory.objects.all()
    serializer_class = SubCategorySerializer
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            return Response({"status": "success", "data": serializer.data,"statuscode":status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        try:
            item = self.get_object()
            self.perform_destroy(item)
            return Response({"status": "success", "message": "Subcategory deleted successfully.", "statuscode":status.HTTP_204_NO_CONTENT}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({"status": "fail", "message": str(e)}, status=status.HTTP_400_BAD_REQUEST)
class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
    permission_classes = [AllowAny]
    pagination_class = ItemPagination  # Apply pagination here

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            return Response({"status": "success", "data": serializer.data,"statuscode":status.HTTP_201_CREATED}, status=status.HTTP_201_CREATED)
        else:
            return Response({"status": "fail", "errors": serializer.errors,"statuscode":status.HTTP_400_BAD_REQUEST}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        try:
            item = self.get_object()
            self.perform_destroy(item)
            return Response({"status": "success","statuscode":status.HTTP_204_NO_CONTENT,"message": "Item deleted successfully."}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({"status": "fail","statuscode":status.HTTP_400_BAD_REQUEST, "message": str(e)}, status=status.HTTP_400_BAD_REQUEST)

#Affilate code start from here

class AffiliateLinkViewSet(viewsets.ModelViewSet):
    print("jiii")
    queryset = AffiliateLink.objects.all()
    serializer_class = AffiliateLinkSerializer
    permission_classes = [AllowAny]

    @action(detail=True, methods=['post'])
    def create_link(self, request, pk=None):
        item = get_object_or_404(Item, pk=pk)

        # Extract the affiliate username from the request data
        affiliate_username = request.data.get('affiliate_username')
        affiliate = get_object_or_404(Affiliate, user__username=affiliate_username)

        # Check if an affiliate link already exists for this affiliate and item
        affiliate_link, created = AffiliateLink.objects.get_or_create(affiliate=affiliate, item=item)

        # If the link already exists, return the existing link without creating a new one
        if not created:
            return Response({
                'message': "Affiliate link already exists.",
                'link': affiliate_link.generate_link(),
                'affiliate_link': AffiliateLinkSerializer(affiliate_link).data
            })

        # If a new link was created, return the new link data
        return Response({
            'message': "New affiliate link created.",
            'link': affiliate_link.generate_link(),
            'affiliate_link': AffiliateLinkSerializer(affiliate_link).data
        })



class ShareItemView(APIView):
    permission_classes = [AllowAny]

    print(f"Received request for unique_code")

    def get(self, request, unique_code):
        print(f"Received request for unique_code: {unique_code}")
        # Fetch the AffiliateLink object using the unique_code
        affiliate_link = get_object_or_404(AffiliateLink, unique_code=unique_code)
        # Get the associated Item
        item = affiliate_link.item
        # Serialize the item data, including images
        serializer = ItemSerializer(item, context={'request': request})
        # Return the item details
        return Response(serializer.data, status=status.HTTP_200_OK)

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser
from django.db.models import Sum, Count
from django.utils.timezone import now
from .models import Order, Category, Item,OrderItem
from .serializers import AdminInsightsSerializer, SalesByCategorySerializer, SalesByRegionSerializer, TopSellingProductSerializer, MonthWiseSalesSerializer, YearSalesSerializer
class AdminInsightsAPIView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        today = now().date()

                # Total Sales Today
        total_sales_today = OrderItem.objects.filter(
            order__created_at__date=today,
            order__payment_status='successful'
        ).aggregate(total=Sum('price'))['total'] or 0
        # Sales by Category
        sales_by_category = Category.objects.annotate(
            total_sales=Sum('subcategory__items__order_items__price')
        ).values('name', 'total_sales')
        sales_by_category_list = SalesByCategorySerializer(sales_by_category, many=True).data
        sales_by_category_count = len(sales_by_category_list)

        # Sales by Region
        sales_by_region = Order.objects.filter(payment_status='successful').values('region').annotate(
            total_sales=Sum('order_items__price')
        )


        sales_by_region_list = SalesByRegionSerializer(sales_by_region, many=True).data
        sales_by_region_count = len(sales_by_region_list)

        # Top Selling Products
        top_selling_products = Item.objects.annotate(
            sales_count=Count('order_items__order')
        ).order_by('-sales_count')[:10]

        top_selling_products_list = TopSellingProductSerializer(top_selling_products, many=True, context={'request': request}).data
        top_selling_products_count = len(top_selling_products_list)

        # Dispatched Orders
        dispatched_orders = Order.objects.filter(delivery_status='dispatched')
        dispatched_orders_list = [{
            'order_id': d_order.id,
            'order_items': [item.item.name for item in d_order.order_items.all()],
            'total_value': sum(item.price for item in d_order.order_items.all()),
            'order_time': d_order.created_at.strftime('%H:%M:%S'),  # Time in HH:MM:SS format
            'order_month': d_order.created_at.strftime('%B'),  # Full month name
            'order_year': d_order.created_at.strftime('%Y'),  # Year in YYYY format
            'region': d_order.region
        } for d_order in dispatched_orders]
        dispatched_orders_count = dispatched_orders.count()

        # Pending Orders
        pending_orders = Order.objects.filter(delivery_status='pending')
        pending_orders_list = [{
            'order_id': order.id,
            'order_items': [item.item.name for item in order.order_items.all()],
            'total_value': sum(item.price for item in order.order_items.all()),
            'order_time': order.created_at.strftime('%H:%M:%S'),  # Time in HH:MM:SS format
            'order_month': order.created_at.strftime('%B'),  # Full month name
            'order_year': order.created_at.strftime('%Y'),  # Year in YYYY format
            'region': order.region
        } for order in pending_orders]
        pending_orders_count = pending_orders.count()

        # Cancelled Orders
        cancelled_orders = Order.objects.filter(delivery_status='cancelled')
        cancelled_orders_list = [str(order.id) for order in cancelled_orders]
        cancelled_orders_count = cancelled_orders.count()

        # Low Stock Alerts
        low_stock_alerts = Item.objects.filter(stock__lte=10)
        low_stock_alerts_list = [item.name for item in low_stock_alerts]
        low_stock_alerts_count = low_stock_alerts.count()

        # Month-Wise Sales
        from django.db.models.functions import TruncMonth
        month_wise_sales = (
            Order.objects.filter(payment_status='successful')
            .annotate(month=TruncMonth('created_at'))  # Group by month
            .values('month')
            .annotate(total_sales=Sum('order_items__price'))  # Sum sales in each month
            .order_by('month')
        )

        formatted_sales = [{
            'month': sale['month'].strftime('%Y-%m'),  # Format as YYYY-MM
            'total_sales': sale['total_sales']
        } for sale in month_wise_sales]
        month_wise_sales_list = MonthWiseSalesSerializer(formatted_sales, many=True).data
        month_wise_sales_count = len(month_wise_sales_list)

        # Year Sales
        from django.db.models.functions import TruncYear
        year_sales = (
            Order.objects.filter(payment_status='successful')
            .annotate(year=TruncYear('created_at'))  # Group by year
            .values('year')
            .annotate(total_sales=Sum('order_items__price'))  # Sum sales in each year
            .order_by('year')
        )

        formatted_year_sales = [{
            'year': sale['year'].year,  # Get the year value
            'total_sales': sale['total_sales']
        } for sale in year_sales]
        year_sales_list = YearSalesSerializer(formatted_year_sales, many=True).data
        year_sales_count = len(year_sales_list)

        data = {
            'total_sales_today': total_sales_today,
            'sales_by_category': sales_by_category_list,
            'sales_by_category_count': sales_by_category_count,
            'sales_by_region': sales_by_region_list,
            'sales_by_region_count': sales_by_region_count,
            'top_selling_products': top_selling_products_list,
            'top_selling_products_count': top_selling_products_count,
            'dispatched_orders': dispatched_orders_list,
            'dispatched_orders_count': dispatched_orders_count,
            'pending_orders': pending_orders_list,
            'pending_orders_count': pending_orders_count,
            'cancelled_orders': cancelled_orders_list,
            'cancelled_orders_count': cancelled_orders_count,
            'low_stock_alerts': low_stock_alerts_list,
            'low_stock_alerts_count': low_stock_alerts_count,
            'month_wise_sales': month_wise_sales_list,
            'month_wise_sales_count': month_wise_sales_count,
            'year_sales': year_sales_list,
            'year_sales_count': year_sales_count,
        }

        serializer = AdminInsightsSerializer(data)
        return Response(data)


# class ItemSearchView(ListAPIView):
#     serializer_class = ItemSerializer
#     permission_classes = [AllowAny]
#
#     def get_queryset(self):
#         query = self.request.query_params.get('q')
#         if query:
#             keywords = query.split()
#             q_objects = Q()
#             for keyword in keywords:
#                 # Perform fuzzy matching
#                 matching_keywords = Keyword.objects.all()
#                 best_match, score = process.extractOne(keyword, [kw.name for kw in matching_keywords])
#
#                 if score >= 70:  # Threshold for fuzzy match
#                     q_objects |= Q(keywords__name__iexact=best_match)
#
#             return Item.objects.filter(q_objects).distinct()
#
#         return Item.objects.none()
#
#     def get(self, request, *args, **kwargs):
#         queryset = self.get_queryset()
#         if queryset.exists():
#             serializer = self.get_serializer(queryset, many=True)
#             return Response(serializer.data, status=status.HTTP_200_OK)
#         return Response({'detail': 'No items found matching the keywords.'}, status=status.HTTP_404_NOT_FOUND)


class ItemSearchView(ListAPIView):

    serializer_class = ItemSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        query = self.request.query_params.get('q', '').strip()

        # Return an empty queryset if query length is less than 2 characters
        if len(query) < 2:
            return Item.objects.none()

        # Use database search first (faster)
        keywords = query.split()
        q_objects = Q()

        for keyword in keywords:
            # Perform direct substring matching in the database (much faster)
            q_objects |= Q(name__icontains=keyword) | Q(keywords__name__icontains=keyword)

        # First attempt to return matches from the database
        results = Item.objects.filter(q_objects).distinct()

        # If no direct database results, fallback to fuzzy matching
        if not results.exists():
            all_item_names = Item.objects.values_list('name', flat=True)
            all_keywords = Keyword.objects.values_list('name', flat=True)
            for keyword in keywords:
                # Fuzzy matching for item names
                best_item_match, item_score = process.extractOne(keyword, all_item_names)
                if item_score >= 70:  # Fuzzy match threshold
                    q_objects |= Q(name__icontains=best_item_match)

                # Fuzzy matching for keywords
                best_keyword_match, keyword_score = process.extractOne(keyword, all_keywords)
                if keyword_score >= 70:  # Fuzzy match threshold
                    q_objects |= Q(keywords__name__icontains=best_keyword_match)

            # Run the fuzzy-matched query
            results = Item.objects.filter(q_objects).distinct()

        return results

    def get(self, request, *args, **kwargs):
        query = self.request.query_params.get('q', '').strip()

        # Check if the query is less than 2 characters


        queryset = self.get_queryset()

        if queryset.exists():
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        # If no items match the query, return a message indicating no results found
        return Response({'detail': 'No items found','status':status.HTTP_200_OK}, status=status.HTTP_200_OK)

class KeywordCreateView(CreateAPIView):
    permission_classes = [AllowAny]
    queryset = Keyword.objects.all()
    serializer_class = KeywordSerializer
class Subcategoryview(mixins.ListModelMixin, viewsets.GenericViewSet):
    queryset = Item.objects.all()  # Define a queryset here
    serializer_class = ItemSerializer
    pagination_class = StandardResultsSetPagination  # Use custom pagination
    permission_classes = [AllowAny]

    def list(self, request, *args, **kwargs):
        subcategory_name = request.query_params.get('q')
        if subcategory_name:
            try:
                subcategory = Subcategory.objects.get(id=subcategory_name)
                self.queryset = self.queryset.filter(subcategory=subcategory)
            except Subcategory.DoesNotExist:
                return Response({"error": "Subcategory not found"}, status=status.HTTP_404_NOT_FOUND)
        return super().list(request, *args, **kwargs)

from django.shortcuts import render, redirect
from django.core.files.storage import FileSystemStorage
import shutil
import os
from .models import Category, Subcategory, Item  # Import your models
from django.conf import settings

def upload_data_folder(request):
    if request.method == 'POST':
        uploaded_folder = request.FILES.get('data_folder')
        if uploaded_folder:
            # Save the uploaded folder
            fs = FileSystemStorage(location='/tmp')
            fs.save(uploaded_folder.name, uploaded_folder)
            extracted_path = os.path.join('/tmp', uploaded_folder.name)

            # Move the uploaded folder to the desired location
            final_directory = os.path.join(settings.BASE_DIR, 'media', 'data')
            shutil.move(extracted_path, final_directory)

            # Run your management command to generate categories, subcategories, and items
            os.system('python manage.py populate_database')

            return redirect('success_page')  # Redirect to a success page or wherever you want

    return render(request, 'upload.html')

class ListSigma(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializerto
    permission_classes = [AllowAny]


@api_view(['GET'])
def search_items(request):
    query = request.GET.get('r', '')
    if query:

        items = Item.objects.filter(name__icontains=query)
    else:
        items = Item.objects.none()
    serializer = ItemSearch(items, many=True)

    return Response(serializer.data)


def item_search_page(request):
    return render(request, 'search.html')

from rest_framework import viewsets
from .models import Advertisement
from .serializers import AdvertisementSerializer

class AdvertisementViewSet(viewsets.ModelViewSet):
    queryset = Advertisement.objects.all()
    serializer_class = AdvertisementSerializer
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import status
from .models import User, Address
from .serializers import UserSerializer, AddressSerializer

# UserViewSet with authentication
class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [AllowAny]  # Ensure only authenticated users access this view

    @action(detail=True, methods=['post'])
    def update_wallet(self, request, pk=None):
        user = self.get_object()
        new_amount = request.data.get('wallet_amount')
        if new_amount is not None:
            user.wallet_amount = new_amount
            user.save()
            return Response({'status': 'wallet updated', 'wallet_amount': user.wallet_amount})
        return Response({'error': 'Invalid data'}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def add_address(self, request, pk=None):
        user = self.get_object()
        serializer = AddressSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# AddressViewSet with authentication
class AddressViewSet(viewsets.ModelViewSet):
    queryset = Address.objects.all()
    serializer_class = AddressSerializer
    permission_classes = [AllowAny]  # Ensure only authenticated users access this view

    def get_queryset(self):
        user = self.request.user
        if user.is_authenticated:
            return Address.objects.filter(user=user)
        return Address.objects.none()  # Return empty queryset for anonymous users
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from django.utils.crypto import get_random_string
from django.core.signing import BadSignature, SignatureExpired, TimestampSigner
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import AffiliateUser
from .serializers import AffiliateUserSerializer

# Define the signer for views
signer = TimestampSigner()

def send_email(subject, body, to_email):
    # Email account credentials
    smtp_server = 'smtpout.secureserver.net'
    smtp_port = 465  # Use 587 for TLS
    smtp_user = 'info@quirckart.com'
    smtp_password = 'Quirc@12345'

    # Create the email content
    msg = MIMEMultipart()
    msg['From'] = smtp_user
    msg['To'] = to_email
    msg['Subject'] = subject

    # Attach the body to the email
    msg.attach(MIMEText(body, 'html'))  # Change 'plain' to 'html'

    # Connect to the SMTP server and send the email
    try:
        with smtplib.SMTP_SSL(smtp_server, smtp_port) as server:
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
            print("Email sent successfully!")
    except Exception as e:
        print(f"Error: {e}")

@api_view(['POST'])
def create_affiliate_user(request):
    if request.method == 'POST':
        name = request.data.get('name')
        mobile = request.data.get('mobile')
        email = request.data.get('email')
        age = request.data.get('age')
        address = request.data.get('address')
        document_type = request.data.get('document_type')
        document_upload = request.FILES.get('document_upload')

        # Generate a random 6-digit uid
        uid = get_random_string(length=6, allowed_chars='0123456789')

        # Create the new affiliate user
        affiliate_user = AffiliateUser.objects.create(
            uid=uid,
            name=name,
            mobile=mobile,
            email=email,
            age=age,
            address=address,
            document_type=document_type,
            document_upload=document_upload
        )


        # Serialize the data
        serializer = AffiliateUserSerializer(affiliate_user, context={'request': request})
        document_upload_url = serializer.data.get('document_upload', None)
        # Prepare email content
        subject = "New Affiliate User Created"
        body = f"""
        <html>
                <body>
                    <p>Hello,</p>
                
                    <p>A new affiliate user has been created with the following details:</p>
                
                    <ul>
                        <li><strong>Name:</strong> {affiliate_user.name}</li>
                        <li><strong>Mobile:</strong> {affiliate_user.mobile}</li>
                        <li><strong>Age:</strong> {affiliate_user.age}</li>
                        <li><strong>Address:</strong> {affiliate_user.address}</li>
                        <li><strong>Document Type:</strong> {affiliate_user.document_type}</li>
                        <li><strong>Document Upload:</strong> <a href="{document_upload_url}">View Document</a></li>
                    </ul>
                
                    <p><strong>Approval Links:</strong></p>
                   <ul style="list-style: none; padding: 0; display: flex; gap: 10px;">
            <li>
                <a href="{serializer.data['approve_link']}" 
                   style="background-color: green; color: white; font-weight: bold; 
                          padding: 10px 20px; text-decoration: none; border-radius: 5px; 
                          display: inline-block; text-align: center;">
                    Approve
                </a>
            </li>
            <li>
                <a href="{serializer.data['reject_link']}" 
                   style="background-color: orange; color: white; 
                          padding: 10px 20px; text-decoration: none; border-radius: 5px; 
                          display: inline-block; text-align: center;">
                    Reject
                </a>
            </li>
            <li>
                <a href="{serializer.data['block_link']}" 
                   style="background-color: red; color: white; 
                          padding: 10px 20px; text-decoration: none; border-radius: 5px; 
                          display: inline-block; text-align: center;">
                    Block
                </a>
            </li>
        </ul>
                    <p>Please take the necessary action.</p>
                
                    <p>Regards,<br>Auto Admin</p>
                </body>
                </html>
        """

        # Send email
        send_email(subject, body, "gargaayush686@gmail.com")  # Change this to the desired recipient

        return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response({'error': 'Invalid request method'}, status=status.HTTP_400_BAD_REQUEST)



import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from django.utils.crypto import get_random_string
from django.core.signing import BadSignature, SignatureExpired, TimestampSigner
from django.contrib.auth.hashers import make_password,check_password
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import AffiliateUser, AffiliateLogin
from .serializers import AffiliateUserSerializer

# Define the signer for views
signer = TimestampSigner()

def send_email2(subject, body, to_email):
    smtp_server = 'smtpout.secureserver.net'
    smtp_port = 465
    smtp_user = 'info@quirckart.com'
    smtp_password = 'Quirc@12345'

    msg = MIMEMultipart()
    msg['From'] = smtp_user
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP_SSL(smtp_server, smtp_port) as server:
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
            print("Email sent successfully!")
    except Exception as e:
        print(f"Error: {e}")

@api_view(['GET'])
def secure_change_affiliate_status(request, token):
    try:
        signed_data = signer.unsign(token, max_age=86400)  # 24 hours expiration
        uid, status_change = signed_data.split(':')

        # Get the affiliate user
        affiliate_user = AffiliateUser.objects.get(uid=uid)

        # Update the status
        affiliate_user.status = status_change
        affiliate_user.save()

        if status_change == 'approved':
            # Create affiliate login credentials
            username = f'affiliate_{affiliate_user.uid}'
            password = get_random_string(length=10)  # Generate a random password
            hashed_password = make_password(password)

            affiliate_login = AffiliateLogin.objects.create(
                affiliate_user=affiliate_user,
                username=username,
                password=hashed_password
            )
            Affiliate.objects.get_or_create(
            user = affiliate_login,
            points = 0
            )

            # Prepare email content with login credentials
            subject = "Your Affiliate Account has been Approved"
            body = f"""
            Hello {affiliate_user.name},

            Your affiliate account has been approved! Here are your login credentials:

            Username: {username}
            Password: {password}

            Please login at: [Your Login URL]

            Regards,
            Your Company Name
            """
            send_email2(subject, body, affiliate_user.email)  # Send email to the affiliate user

        return Response({'message': f'Status changed to {status_change}'}, status=status.HTTP_200_OK)

    except (BadSignature, SignatureExpired):
        return Response({'error': 'Invalid or expired link'}, status=status.HTTP_400_BAD_REQUEST)

from django.contrib.auth.hashers import check_password
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import AffiliateLogin
from rest_framework_simplejwt.tokens import RefreshToken

class AffiliateLoginView(APIView):
    def post(self, request):
        serializer = AffiliateLoginSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data['username']
            password = serializer.validated_data['password']

            try:
                user = AffiliateLogin.objects.get(username=username)

                # Use check_password to verify the raw password against the hashed password
                if check_password(password, user.password):
                    # Password is correct, generate tokens
                    refresh = RefreshToken.for_user(user)

                    return Response({
                        "status": "OK",
                        "id": user.id,
                        "username": user.username,
                        "token": str(refresh.access_token),  # Access token
                        "refresh_token": str(refresh),      # Refresh token
                        "user_details": {
                            "id": user.id,
                            "username": user.username
                        }
                    }, status=status.HTTP_200_OK)
                else:
                    # Invalid password
                    return Response({"error": "Invalid password"}, status=status.HTTP_401_UNAUTHORIZED)

            except AffiliateLogin.DoesNotExist:
                return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Item, Comment, Reply
from .serializers import CommentSerializer, ReplySerializer
from django.contrib.auth.models import User
from rest_framework.permissions import IsAdminUser

@api_view(['POST'])
def add_comment(request, item_id):
    try:
        item = Item.objects.get(id=item_id)
    except Item.DoesNotExist:
        return Response({'error': 'Item not found'}, status=status.HTTP_404_NOT_FOUND)

    content = request.data.get('content', '')
    if content:
        comment = Comment.objects.create(item=item, user=request.user, content=content)
        return Response({'message': 'Comment added successfully'}, status=status.HTTP_201_CREATED)
    return Response({'error': 'Content cannot be empty'}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def reply_to_comment(request, comment_id):
    try:
        comment = Comment.objects.get(id=comment_id)
    except Comment.DoesNotExist:
        return Response({'error': 'Comment not found'}, status=status.HTTP_404_NOT_FOUND)

    content = request.data.get('content', '')
    if content:
        reply, created = Reply.objects.get_or_create(comment=comment, user=request.user, content=content)
        if created:
            return Response({'message': 'Reply added successfully'}, status=status.HTTP_201_CREATED)
        else:
            return Response({'error': 'A reply to this comment already exists'}, status=status.HTTP_400_BAD_REQUEST)
    return Response({'error': 'Content cannot be empty'}, status=status.HTTP_400_BAD_REQUEST)

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import AffiliateLink, Affiliate
from .serializers import AffiliateLinkSerializer
from django.shortcuts import get_object_or_404

from rest_framework import viewsets
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import AffiliateLink, Affiliate
from .serializers import AffiliateLinkSerializer

from rest_framework import viewsets
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import AffiliateLink, Affiliate
from .serializers import AffiliateLinkSerializer

class AffiliateLinkViewSet(viewsets.ModelViewSet):
    queryset = AffiliateLink.objects.all()
    serializer_class = AffiliateLinkSerializer

    def get_affiliate_links(self, request, username=None):
        # Get affiliate using the username
        affiliate = get_object_or_404(Affiliate, user=username)

        # Retrieve all links associated with the affiliate
        affiliate_links = AffiliateLink.objects.filter(affiliate=affiliate)

        # Check if no links found, return 200 OK with "No links found" message
        if not affiliate_links.exists():
            return Response({"message": "No links found"}, status=200)

        # Serialize the affiliate links data
        serializer = AffiliateLinkSerializer(affiliate_links, many=True)

        # Prepare response including total points of the affiliate
        response_data = {
            "affiliate_username": affiliate.user.username,
            "total_tokens": affiliate.points,  # Display the total points of the affiliate
            "links": serializer.data  # All the links generated by the affiliate
        }

        return Response(response_data)
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import razorpay
from django.conf import settings
import json

# Initialize the Razorpay client with your API keys
client = razorpay.Client(auth=(settings.RAZORPAY_API_KEY, settings.RAZORPAY_API_SECRET))

@csrf_exempt
def initiate_payment(request):
    if request.method == 'POST':
        try:
            # Get the payment amount from the request
            amount = int(request.POST.get('amount', 0))
            print(amount)
            if amount <= 0:
                return JsonResponse({'error': 'Invalid amount'}, status=400)

            # Create an order with Razorpay
            data = {
                'amount': amount * 100,  # Razorpay expects the amount in paise
                'currency': 'INR',
                'payment_capture': '1'  # Auto capture the payment after successful authorization
            }
            order_response = client.order.create(data=data)

            # Return the order id in the response
            return JsonResponse({'id': order_response['id'], 'status': 'success'}, status=200)
        except Exception as e:
            # Handle any errors in the payment process
            return JsonResponse({'error': str(e)}, status=500)
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=405)


from rest_framework import viewsets
from .models import Order
from .serializers import OrderSerializer

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

from rest_framework import viewsets
from .models import Customer
from .serializers import CustomerSerializer

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer

from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Customer
from .serializers import CustomerUserSerializer

class CustomerSearchCreateView(APIView):

    def post(self, request, *args, **kwargs):
        username = request.data.get('username')
        password = request.data.get('password')

        if not username or not password:
            return Response({'error': 'Username and password are required.'}, status=status.HTTP_400_BAD_REQUEST)

        # Check if user with the username already exists
        try:
            user = User.objects.get(username=username)
            customer = Customer.objects.get(user=user)
            return Response({'customer_id': customer.id}, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            # If user does not exist, create a new user and customer
            user = User.objects.create_user(username=username, password=password)
            customer = Customer.objects.create(user=user)
            return Response({'customer_id': customer.id, 'message': 'New customer created'}, status=status.HTTP_201_CREATED)

        except Customer.DoesNotExist:
            return Response({'error': 'Customer does not exist for the given user.'}, status=status.HTTP_404_NOT_FOUND)

def start(request):
    return render(request,'index.html')